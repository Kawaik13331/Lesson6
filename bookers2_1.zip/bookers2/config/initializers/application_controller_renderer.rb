# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'b3c5472e4cc601236e8c67016b2bd27d99fd128effb940d33f5149f0d37f0220b667f11b0a81a5f9cd6c80a1d22b45d745ccb3679e76deee1fd662e7e0330ff9'